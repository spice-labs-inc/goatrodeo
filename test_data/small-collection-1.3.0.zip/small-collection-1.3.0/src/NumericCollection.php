<?php

namespace Small\Collection;

use Small\Collection\Contract\CheckValueInterface;
use Small\Collection\Exception\ValueCheckFailedException;

class NumericCollection extends Collection implements CheckValueInterface
{

    /**
     * Values must be numeric
     * @param mixed $value
     * @return $this
     * @throws ValueCheckFailedException
     */
    public function checkValue(mixed $value): static
    {

        if (!is_numeric($value)) {
            throw new ValueCheckFailedException('The value of a NumericCollection must be numeric');
        }

        return $this;

    }

    /**
     * Get minimum value
     * @param bool $returnKey
     * @return int|float
     */
    public function min(bool $returnKey = false): int|float
    {

        // Init result
        $min = null;
        $minKey = null;

        // For each values
        foreach ($this as $key => $value) {

            // Check if min changed
            if ($min > $value || $min === null) {
                $min = $value;
                $minKey = $key;
            }

        }

        // Return key or value of minimum
        if ($returnKey) {
            return $minKey;
        } else {
            return $min;
        }

    }

    /**
     * Get maximum value
     * @param bool $returnKey
     * @return int|float
     */
    public function max(bool $returnKey = false): int|float
    {

        // Init result
        $max = null;
        $maxKey = null;

        // For each values
        foreach ($this as $key => $value) {

            // Check if min changed
            if ($max < $value || $max === null) {
                $max = $value;
                $maxKey = $key;
            }

        }

        // Return key or value of minimum
        if ($returnKey) {
            return $maxKey;
        } else {
            return $max;
        }

    }

    /**
     * Sum all values
     * @return int|float
     */
    public function sum(): int|float
    {

        $sum = 0;
        foreach ($this as $value) {
            $sum += $value;
        }

        return $sum;
    }

    /**
     * Format number to StringCollection
     * @param int $decimal
     * @param string|null $decimal_separator
     * @param string|null $thousands_separator
     * @return StringCollection
     */
    public function numberFormat(int $decimal, ?string $decimal_separator = '.', ?string $thousands_separator = ','): StringCollection
    {

        $array = [];
        foreach ($this as $key => $value) {
            $array[$key] = number_format($value, $decimal, $decimal_separator, $thousands_separator);
        }

        return new StringCollection($array);

    }

}