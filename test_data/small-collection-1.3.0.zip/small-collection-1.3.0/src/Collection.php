<?php

namespace Small\Collection;

use App\Service\Collection\Contract\CollectionCheckValue;
use App\Service\Collection\Contract\CollectionItemHasPosition;
use App\Service\Collection\Contract\CollectionNumericKeys;
use Small\Collection\Contract\CheckValueInterface;
use Small\Collection\Exception\CollectionException;
use Small\Collection\Exception\ForbiddenUsageException;

class Collection implements \ArrayAccess, \Countable, \Iterator, \JsonSerializable
{

    protected array $array = [];

    public function __construct(array $array = []) {

        // Set values of array to new collection
        foreach ($array as $key => $item) {
            $this->set($key, $item);
        }

    }

    /**
     * Transform collection to array
     * @return array
     */
    public function toArray(): array
    {

        $result = [];
        foreach ($this->array as $key => $value) {
            if ($value instanceof Collection) {
                $result[$key] = $value->toArray();
            } else {
                $result[$key] = $value;
            }
        }

        return $result;

    }

    /**
     * Set value
     * @param mixed $key
     * @param mixed $value
     * @return $this
     */
    public function set(mixed $key, mixed $value): self
    {

        // Check value
        if ($this instanceof CheckValueInterface) {
            $this->checkValue($value);
        }

        // If is array, transform to collection
        if (is_array($value)) {
            $this->array[$key] = new Collection($value);

            return $this;
        }

        // Set value
        $this->array[$key] = $value;

        return $this;

    }

    /**
     * Check if offset exists
     * @param mixed $offset
     * @return bool
     */
    public function offsetExists(mixed $offset): bool
    {

        return array_key_exists($offset, $this->array);

    }

    /**
     * Get value of offset
     * @param mixed $offset
     * @return mixed
     */
    public function offsetGet(mixed $offset): mixed
    {

        return $this->array[$offset];

    }

    /**
     * Set offset value
     * @param mixed $offset
     * @param mixed $value
     * @return void
     */
    public function offsetSet(mixed $offset, mixed $value): void
    {

        // If offset is empty => operator []
        if (empty($offset) && $offset !== 0) {
            for($offset = 0; array_key_exists($offset, $this->array); $offset++);
        }

        // Set array with new value
        $this->set($offset, $value);

    }

    /**
     * Unset offset
     * @param mixed $offset
     * @return void
     */
    public function offsetUnset(mixed $offset): void
    {

        unset($this->array[$offset]);

    }

    /**
     * Iterator rewind bridge
     * @return void
     */
    function rewind(): void {
        reset($this->array);
    }

    /**
     * Iterator current bridge
     * @return mixed
     */
    function current(): mixed {
        return current($this->array);
    }

    /**
     * Iterator key bridge
     * @return int|string|null
     */
    function key(): int|string|null {
        return key($this->array);
    }

    /**
     * Iterator next bridge
     * @return void
     */
    function next(): void {
        next($this->array);
    }

    /**
     * Iterator valid bridge
     * @return bool
     */
    function valid(): bool {
        return key($this->array) !== null;
    }

    /**
     * Count items
     * @return int
     */
    public function count(): int
    {

        return count($this->array);

    }

    /**
     * Filter collection by array of keys
     * @param array $filter
     * @return Collection
     */
    public function filterKeysByArray(array $filter): Collection
    {

        $result = new Collection();

        foreach ($this->array as $key => $value) {
            if (array_key_exists($key, $filter) && $filter[$key]) {
                if (is_array($filter[$key]) && $value instanceof Collection) {
                    $result[$key] = $value->filterKeysByArray($filter[$key]);
                } else {
                    $result[$key] = $value;
                }
            }
        }

        return $result;

    }

    /**
     * Filter by closure => closure must return true/false/array with keys to filter
     * @param string|\Closure $closure
     * @return static
     */
    public function filterKeysByClosure(string|\Closure $closure): static
    {

        /** @phpstan-ignore-next-line */
        $result = new static();
        foreach ($this->array as $key => $value) {
            if (is_string($closure)) {
                $test = $this->$closure($key, $value);
            } else {
                $test = $closure($key, $value);
            }
            if ($test) {
                $result[$key] = $this[$key];
            }
        }

        return $result;

    }

    /**
     * Merge array or collection to collection
     * @param array|Collection $array
     * @return $this
     */
    public function merge(array|Collection $array): self
    {

        if ($array instanceof Collection) {
            $array = $array->array;
        }

        foreach ($array as $key => $value) {
            if (is_int($key)) {
                $this[] = $value;
            } else {
                $this->set($key, $value);
            }
        }

        return $this;
    }

    /**
     * Add values that not exists
     * @param array|Collection $array
     * @return $this
     */
    public function unionValues(array|Collection $array, $distinct = true): self
    {

        if ($array instanceof Collection) {
            $array = $array->array;
        }

        foreach ($array as $value) {
            if (!in_array($value, $this->array) || !$distinct) {
                $this->array[] = $value;
            }
        }

        return $this;
    }

    /**
     * Return first key of first occurrence of value
     * @param mixed $value
     * @return mixed
     * @throws CollectionException
     */
    public function getFirstKeyFromValue(mixed $value): mixed
    {

        foreach ($this->array as $key => $item) {
            if ($item == $value) {
                return $key;
            }
        }

        throw new CollectionException('Value not found');

    }

    /**
     * Return first key of first occurrence of value recursively
     * @param mixed $value
     * @return Collection
     */
    public function getFirstKeyFromValueRecursive(mixed $value): Collection
    {

        foreach ($this->array as $key => $item) {
            if ($item == $value) {
                return new Collection([$key]);
            }

            if ($item instanceof Collection) {
                $resultCollection = $item->getFirstKeyFromValueRecursive($value);
                if (count($resultCollection) > 0) {
                    $result = new Collection([$key]);
                    return $result->unionValues($resultCollection, false);
                }
            }
        }

        return new Collection();

    }

    /**
     * Sort by values
     * @param bool $recursive
     * @param string|\Closure|null $sortMethod
     * @return $this
     * @throws ForbiddenUsageException
     */
    public function sort(bool $recursive = true, string|\Closure|null $sortMethod = null): self
    {

        if ($recursive && $sortMethod !== null) {
            throw new ForbiddenUsageException('Can\'t use recursive exception with $sortMethod param');
        }

        // Sort
        if ($sortMethod === null) {
            sort($this->array);
        } else if (is_string($sortMethod)) {
            usort($this->array, [$this, $sortMethod]);
        } else {
            usort($this->array, $sortMethod);
        }

        // If recursive, sort sub collections
        if ($recursive) {
            foreach ($this->array as $value) {
                if ($value instanceof Collection) {
                    $value->sort($recursive);
                }
            }
        }

        return $this;

    }

    /**
     * Sort by keys
     * @param bool $recursive
     * @param string|\Closure|null $sortMethod
     * @return $this
     * @throws ForbiddenUsageException
     */
    public function ksort(bool $recursive = true, string|\Closure|null $sortMethod = null): self
    {

        if ($recursive && $sortMethod !== null) {
            throw new ForbiddenUsageException('Can\'t use recursive exception with $sortMethod param');
        }

        // Sort
        if ($sortMethod === null) {
            ksort($this->array);
        } else if (is_string($sortMethod)) {
            uksort($this->array, [$this, $sortMethod]);
        } else {
            uksort($this->array, $sortMethod);
        }

        // If recursive, sort sub collections
        if ($recursive) {
            foreach ($this->array as $value) {
                if ($value instanceof Collection) {
                    $value->ksort($recursive);
                }
            }
        }

        return $this;

    }

    /**
     * Intersect this collection with array or collection by values
     * @param Collection|array $collection
     * @return self
     */
    public function intersect(Collection|array $collection): self
    {

        if ($collection instanceof Collection) {
            $array = &$collection->array;
        } else {
            $array = &$collection;
        }
        $resultArray = array_intersect($this->array, $array);

        $result = new self($resultArray);

        return $result;

    }

    /**
     * Intersect this collection with array or collection by key
     * @param Collection|array $collection
     * @return self
     */
    public function intersectKey(Collection|array $collection): self
    {

        if ($collection instanceof Collection) {
            $array = &$collection->array;
        } else {
            $array = &$collection;
        }
        $resultArray = array_intersect_key($this->array, $array);

        $result = new self($resultArray);

        return $result;

    }

    /**
     * Map collection on closure
     * @param \Closure|string $closure
     * @return Collection
     */
    public function map(\Closure|string $closure)
    {

        if (is_string($closure)) {
            $closure = [$this, $closure];
        }

        $array = [];
        foreach ($this as $key => $value) {
            $array[$key] = $closure($key, $value);
        }

        return new static($array);

    }

    /**
     * Get values as array with numeric keys
     * @return array
     */
    public function values(): array
    {
        return array_values($this->array);
    }

    /**
     * Implode to string
     * @param string|array|Collection $separator
     * @return string
     */
    public function implode(string|array|Collection $separator): string
    {

        if ($separator instanceof Collection) {
            $separator = $separator->array;
        }

        return implode($separator, $this->array);

    }

    /**
     * Remove keys
     * @return self
     */
    public function removeKeys(): self
    {

        $this->array = array_values($this->array);

        return $this;

    }

    /**
     * Prepare data for json_encode
     * @return array
     */
    public function jsonSerialize(): array
    {
        return $this->toArray();
    }

}