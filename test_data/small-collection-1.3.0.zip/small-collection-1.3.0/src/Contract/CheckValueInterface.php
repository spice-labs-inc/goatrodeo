<?php

namespace Small\Collection\Contract;

interface CheckValueInterface
{

    /**
     * Throw an exception if value has bad format
     * @param mixed $value
     * @return $this
     */
    public function checkValue(mixed $value): static;

}