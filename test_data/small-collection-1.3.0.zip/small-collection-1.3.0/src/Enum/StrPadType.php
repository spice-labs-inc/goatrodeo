<?php

namespace Small\Collection\Enum;

enum StrPadType: int
{

    case left = 0;
    case right = 1;
    case both = 2;

}