<?php

namespace Small\Collection\Enum;

enum MassOperations
{

    case avg;

}