<?php

namespace Small\Collection;

use Small\Collection\Contract\CheckValueInterface;
use Small\Collection\Enum\StrPadType;
use Small\Collection\Exception\ForbiddenUsageException;
use Small\Collection\Exception\ValueCheckFailedException;

class StringCollection extends Collection implements CheckValueInterface
{

    /**
     * Value must be string
     * @param mixed $value
     * @return $this
     * @throws ValueCheckFailedException
     */
    public function checkValue(mixed $value): static
    {

        if (!is_string($value)) {
            throw new ValueCheckFailedException('The values for StringCollection must be string');
        }

        return $this;

    }

    /**
     * Left trim on all occurrences
     * @return $this
     */
    public function ltrim(): self
    {

        foreach ($this as &$value) {
            $value = ltrim($value);
        }

        return $this;

    }

    /**
     * Right trim on all occurrences
     * @return $this
     */
    public function rtrim(): self
    {

        foreach ($this as &$value) {
            $value = rtrim($value);
        }

        return $this;

    }

    /**
     * Trim on all occurrences
     * @return $this
     */
    public function trim(): self
    {

        foreach ($this as &$value) {
            $value = trim($value);
        }

        return $this;

    }

    /**
     * Pad all occurrences
     * @param string $string
     * @param int $length
     * @param string $pad_string
     * @param int|StrPadType $pad_type
     * @return $this
     */
    public function pad(string $string, int $length, string $pad_string = ' ', int|StrPadType $pad_type = StrPadType::left): self
    {

        foreach ($this as &$value) {
            $value = str_pad($string, $length, $pad_string, $pad_type instanceof StrPadType ? $pad_type->value : $pad_type);
        }

        return $this;

    }

    /**
     * Set first char to lower case on all occurrences
     * @return $this
     */
    public function lcfirst(): self
    {

        foreach ($this as &$value) {
            $value = lcfirst($value);
        }

        return $this;

    }

    /**
     * Set first char to upper case on all occurrences
     * @return $this
     */
    public function ucfirst(): self
    {

        foreach ($this as &$value) {
            $value = ucfirst($value);
        }

        return $this;

    }

    /**
     * To lower case on all occurrences
     * @return $this
     */
    public function tolower(): self
    {

        foreach ($this as &$value) {
            $value = strtolower($value);
        }

        return $this;

    }

    /**
     * To upper case on all occurrences
     * @return $this
     */
    public function toupper(): self
    {

        foreach ($this as &$value) {
            $value = strtoupper($value);
        }

        return $this;

    }

    /**
     * Replace part of string on all occurrences
     * @param array|StringCollection|string $search
     * @param array|StringCollection|string $replace
     * @return $this
     */
    public function replace(array|StringCollection|string $search, array|StringCollection|string $replace): self
    {

        foreach ($this as &$value) {
            $value = str_replace(
                $search instanceof StringCollection ? $search->array : $search,
                $replace instanceof StringCollection ? $search->array : $replace,
                $value
            );
        }

        return $this;
    }

    /**
     * Return new collection with occurrences that contains $needle
     * @param string $needle
     * @return self
     */
    public function contains(string $needle): self
    {

        $result = new self();
        foreach ($this as $key => $haystack) {
            if (str_contains($haystack, $needle)) {
                $result[$key] = $haystack;
            }
        }

        return $result;

    }

    /**
     * Return new collection with occurrences that start with $needle
     * @param string $needle
     * @return self
     */
    public function startWith(string $needle): self
    {

        $result = new self();
        foreach ($this as $key => $haystack) {
            if (str_starts_with($haystack, $needle)) {
                $result[$key] = $haystack;
            }
        }

        return $result;

    }

    /**
     * Return new collection with occurrences that match with $regex
     * @param string $regex
     * @return self
     */
    public function matchRegex(string $regex): self
    {

        $result = new self();
        foreach ($this as $key => $haystack) {
            if (preg_match($regex, $haystack) == 1) {
                $result[$key] = $haystack;
            }
        }

        return $result;

    }

}