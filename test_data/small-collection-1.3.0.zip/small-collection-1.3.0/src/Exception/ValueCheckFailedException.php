<?php

namespace Small\Collection\Exception;

class ValueCheckFailedException extends CollectionException
{

}