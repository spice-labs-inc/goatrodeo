<?php

namespace Small\Collection\Exception;

class ForbiddenUsageException extends CollectionException
{

}