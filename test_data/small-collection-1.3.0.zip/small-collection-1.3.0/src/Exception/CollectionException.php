<?php

namespace Small\Collection\Exception;

class CollectionException extends \Exception
{

}