<?php
/*
 * This file is a part of small-collection
 * Copyright 2023 - Sébastien Kus
 * Under GNU GPL V3 licence
 */

namespace Small\Collection\Test;

use PHPUnit\Framework\TestCase;
use Small\Collection\Collection;
use Small\Collection\Exception\CollectionException;

class CollectionTest extends TestCase
{

    public function testToArray(): void
    {

        $collection = new Collection([0 => 'test']);
        $array = $collection->toArray();

        self::assertCount(1, $array);
        self::assertEquals('test', $array[0]);

    }

    public function testSet(): void
    {

        $collection = new Collection();

        $collection->set(0, 1);
        self::assertEquals(1, $collection[0]);

        $collection[0] = 2;
        self::assertEquals(2, $collection[0]);

        $collection['assoc'] = 'assoc1';
        self::assertEquals('assoc1', $collection['assoc']);

        $collection[] = 3;
        self::assertEquals(3, $collection[1]);

        $collection[] = [1, 2, 3];
        self::assertCount(3, $collection[2]);
        self::assertEquals(1, $collection[2][0]);
        self::assertEquals(2, $collection[2][1]);
        self::assertEquals(3, $collection[2][2]);

    }

    public function testArrayAccess(): void
    {

        $collection = new Collection([1, 2, 3]);
        foreach ($collection as $item => $value) {
            self::assertEquals($item + 1, $value);
        }
        unset($collection[0]);
        self::assertFalse(isset($collection[0]));
        self::assertCount(2, $collection);

    }

    public function testFilters(): void
    {

        $collection = new \Small\Collection\Test\TestClasses\Collection([
            'test1' => 1,
            'test2' => 2,
            'test3' => 3,
            4 => 4,
            'array' => [
                'subtest1' => 5,
                'subtest2' => [6, 7, 8],
            ]
        ]);

        $filtered = $collection->filterKeysByArray([
            'test1' => true,
            4 => true,
            'array' => ['subtest2' => true],
        ]);
        self::assertEquals(1, $filtered['test1']);
        self::assertEquals(4, $filtered[4]);
        self::assertInstanceOf(Collection::class, $filtered['array']);
        self::assertInstanceOf(Collection::class, $filtered['array']['subtest2']);
        self::assertCount(3, $filtered['array']['subtest2']);
        self::assertFalse(isset($filtered['test2']));
        self::assertFalse(isset($filtered['test3']));
        self::assertFalse(isset($filtered['array']['subtest1']));

        $filtered = $collection->filterKeysByClosure(function (mixed $key, mixed $value): bool {
            return is_int($value) && $value >= 3;
        });
        self::assertCount(2, $filtered);
        self::assertFalse(isset($filtered['test1']));
        self::assertFalse(isset($filtered['test2']));
        self::assertFalse(isset($filtered['array']));
        self::assertEquals(3, $filtered['test3']);
        self::assertEquals(4, $filtered[4]);

        $filtered = $collection->filterKeysByClosure('testFilter');
        self::assertCount(2, $filtered);
        self::assertFalse(isset($filtered['test1']));
        self::assertFalse(isset($filtered['test2']));
        self::assertFalse(isset($filtered['array']));
        self::assertEquals(3, $filtered['test3']);
        self::assertEquals(4, $filtered[4]);

    }

    public function testCollectionSetsMethods(): void
    {

        $collection1 = new Collection([1, 2, 3, 4, 5, 6, 7]);
        $collection2 = new Collection([5, 6, 7, 8, 9, 10, 11, 12, 13]);

        $intersect1 = $collection1->intersect($collection2);
        self::assertCount(3, $intersect1);
        self::assertEquals(5, $intersect1[4]);
        self::assertEquals(6, $intersect1[5]);
        self::assertEquals(7, $intersect1[6]);

        $intersect2 = $collection2->intersectKey($collection1);
        self::assertCount(count($collection1), $intersect2);
        self::assertEquals(5, $intersect2[0]);
        self::assertEquals(6, $intersect2[1]);
        self::assertEquals(7, $intersect2[2]);
        self::assertEquals(8, $intersect2[3]);
        self::assertEquals(9, $intersect2[4]);
        self::assertEquals(10, $intersect2[5]);
        self::assertEquals(11, $intersect2[6]);

        $collection2[100] = 100;
        $collection1->merge($collection2);
        self::assertCount(10, $collection1);
        self::assertEquals(5, $collection1[0]);
        self::assertEquals(6, $collection1[1]);
        self::assertEquals(7, $collection1[2]);
        self::assertEquals(8, $collection1[3]);
        self::assertEquals(9, $collection1[4]);
        self::assertEquals(10, $collection1[5]);
        self::assertEquals(11, $collection1[6]);
        self::assertEquals(12, $collection1[7]);
        self::assertEquals(13, $collection1[8]);
        self::assertEquals(100, $collection1[100]);

        $collection1 = new Collection([1, 2, 3]);
        $collection2 = new Collection([2, 3, 4]);
        $collection1->unionValues($collection2);
        self::assertCount(4, $collection1);
        self::assertEquals(1, $collection1[0]);
        self::assertEquals(2, $collection1[1]);
        self::assertEquals(3, $collection1[2]);
        self::assertEquals(4, $collection1[3]);

        $collection1 = new Collection([1, 2, 3]);
        $collection2 = new Collection([2, 3, 4]);
        $collection1->unionValues($collection2, false);
        self::assertCount(6, $collection1);
        self::assertEquals(1, $collection1[0]);
        self::assertEquals(2, $collection1[1]);
        self::assertEquals(3, $collection1[2]);
        self::assertEquals(2, $collection1[3]);
        self::assertEquals(3, $collection1[4]);
        self::assertEquals(4, $collection1[5]);

    }

    public function testSearches(): void
    {

        $collection1 = new Collection([1, 2, 3, 1, 2, 3]);
        $firstKey = $collection1->getFirstKeyFromValue(3);
        self::assertEquals(2, $firstKey);

        $e = null;
        try {
            $collection1->getFirstKeyFromValue(151);
        } catch (\Exception $e) {}
        self::assertInstanceOf(CollectionException::class, $e);

        $collection2 = new Collection([1, 2, [3, 4, 5], 6]);
        $firstKey = $collection2->getFirstKeyFromValueRecursive(3);
        self::assertInstanceOf(Collection::class, $firstKey);
        self::assertCount(2, $firstKey);
        self::assertEquals(2, $firstKey[0]);
        self::assertEquals(0, $firstKey[1]);

        $firstKey = $collection2->getFirstKeyFromValueRecursive(151);
        self::assertInstanceOf(Collection::class, $firstKey);
        self::assertCount(0, $firstKey);

    }

    public function testSort(): void
    {

        $collection = new Collection([3, 2, 5]);
        $collection->sort(false);
        self::assertEquals(2, $collection[0]);
        self::assertEquals(3, $collection[1]);
        self::assertEquals(5, $collection[2]);

        $collection = new Collection([3 => 'a', 2 => 'b', 5 => 'c']);
        $collection->ksort(false);
        $keys = [];
        $values = [];
        foreach ($collection as $key => $item) {
            $keys[] = $key;
            $values[] = $item;
        }
        self::assertEquals(2, $keys[0]);
        self::assertEquals(3, $keys[1]);
        self::assertEquals(5, $keys[2]);
        self::assertEquals('b', $values[0]);
        self::assertEquals('a', $values[1]);
        self::assertEquals('c', $values[2]);

        $collection = new Collection([3, 2, 5]);
        $collection->sort(false, function($a, $b) {
            if ($a==$b) return 0;
            return ($a>$b)?-1:1;
        });
        self::assertEquals(5, $collection[0]);
        self::assertEquals(3, $collection[1]);
        self::assertEquals(2, $collection[2]);

        $collection = new Collection([3 => 'a', 2 => 'b', 5 => 'c']);
        $collection->ksort(false, function($a, $b) {
            if ($a==$b) return 0;
            return ($a>$b)?-1:1;
        });
        $keys = [];
        $values = [];
        foreach ($collection as $key => $item) {
            $keys[] = $key;
            $values[] = $item;
        }
        self::assertEquals(2, $keys[2]);
        self::assertEquals(3, $keys[1]);
        self::assertEquals(5, $keys[0]);
        self::assertEquals('b', $values[2]);
        self::assertEquals('a', $values[1]);
        self::assertEquals('c', $values[0]);

        $collection = new Collection([[7, 6, 5], 3, 2, 5]);
        $collection->sort();
        self::assertEquals(2, $collection[1]);
        self::assertEquals(3, $collection[2]);
        self::assertEquals(5, $collection[3]);
        self::assertEquals(5, $collection[0][0]);
        self::assertEquals(6, $collection[0][1]);
        self::assertEquals(7, $collection[0][2]);

        $collection = new Collection([3 => 'a', 2 => [2 => 'b', 1 => 'd'], 5 => 'c']);
        $collection->ksort();
        $keys = [];
        $values = [];
        foreach ($collection as $key => $item) {
            $keys[] = $key;
            $values[] = $item;
        }
        self::assertEquals(2, $keys[0]);
        self::assertEquals(3, $keys[1]);
        self::assertEquals(5, $keys[2]);
        self::assertInstanceOf(Collection::class, $values[0]);
        self::assertEquals('a', $values[1]);
        self::assertEquals('c', $values[2]);
        $values2 = [];
        foreach ($values[0] as $value) {
            $values2[] = $value;
        }
        self::assertEquals('d', $values2[0]);
        self::assertEquals('b', $values2[1]);

    }

}