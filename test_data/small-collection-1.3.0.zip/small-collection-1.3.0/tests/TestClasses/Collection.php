<?php
/*
 * This file is a part of small-collection
 * Copyright 2023 - Sébastien Kus
 * Under GNU GPL V3 licence
 */

namespace Small\Collection\Test\TestClasses;

class Collection extends \Small\Collection\Collection
{

    public static function testFilter(mixed $key, mixed $value): bool
    {

        return is_int($value) && $value > 2;

    }

}