# small-collection

small-collection provide generic collection classes.

## Base collection

### Use it as array

The *Small\Collection\Collection* class is the base collection class.

You can create an empty collection :
```php
$collection = new \Small\Collection\Collection();
```

Or initialize it with an array :
```php
$collection = new Small\Collection\Collection([1, 2, 3, 4]);
```

The collection has the behaviour of an array but is also an object :
```php
$collection = new Small\Collection\Collection([1, 2, 3, 4]);
foreach ($collection as $value) {
    echo $value;
}
```

### Use it as an object

#### set

You can set a value for a specific key :
```php
$collection = new \Small\Collection\Collection();
$key = 101;
$value = 'test';
$collection->set($key, $value);
```

And use it :
```php
echo $collection[$key];
```

#### filterKeysByArray

You can filter the collection to a new collection via a selection array :

```php
$collection = new Small\Collection\Collection([
    'test1' => 1,
    'test2' => 2,
    'test3' => 3,
    4 => 4,
    'array' => [
        'subtest1' => 5,
        'subtest2' => [6, 7, 8],
    ]
]);
echo json_encode($collection->filterKeysByArray([
    'test1' => true,
    4 => true,
    'array' => ['subtest2' => true],
]));
```

The output will be :
````json
{
  "test1": 1,
  "4": 4,
  "array": {
    "subtest2": [
      6, 
      7, 
      8
    ]
  }
}
````

#### filterKeysByClosure

The filter keys by closure is a method allow you to filter the collection with complex rules.

Pass a closure (or a static method of the collection) that get key and value. If your closure return true, the key is not filtered and if false, the key is filtered.

```php
$collection = new Small\Collection\Collection([
    'test1' => 'a',
    'test2' => 'b',
    'test3' => 3,
    4 => 4,
    'array' => [
        'subtest1' => 'c',
        'subtest2' => [6, 7, 8],
    ]
]);
echo json_encode($collection->filterKeysByClosure(function($key, $value) {
    return is_int($value);
}));
```

The output will be :
````json
{
  "test3": 3,
  "4": 4
}
````

#### merge

You can merge a collection into another collection :
```php
$collection1 = new Small\Collection\Collection([1, 2, 3, 4, 5]);
$collection2 = new Small\Collection\Collection([5 => 6, 6 => 7]);
$collection1->merge($collection2);
echo json_encode($collection1);
```

Will output :
```json
[1,2,3,4,5,5,7]
```

The merge match on key, then if you have conflict on key, the *$collection2* will overwrite the *$collection1* value :
```php
$collection1 = new Small\Collection\Collection([1, 2, 3, 4, 5]);
$collection2 = new Small\Collection\Collection([6, 7]);
$collection1->merge($collection2);
echo json_encode($collection1);
```

Will output :
```json
[6,7,3,4,5]
```

#### unionValues

You can add all values of a collection to another collection :

```php
$collection1 = new \Small\Collection\Collection([1, 2, 3, 4]);
$collection2 = new \Small\Collection\Collection([4, 5, 6]);
$collection1->unionValues($collection2);
echo json_encode($collection1);
```

Will output :

```php
[1, 2, 3, 4, 5, 6]
```

You can force method to keep duplicates

```php
$collection1 = new \Small\Collection\Collection([1, 2, 3, 4]);
$collection2 = new \Small\Collection\Collection([4, 5, 6]);
$collection1->unionValues($collection2, false);
echo json_encode($collection1);
```

Will output :

```php
[1, 2, 3, 4, 4, 5, 6]
```

#### getFirstKeyFromValue

This method return the key of first value and throw Exception if not found :

```php
$collection1 = new \Small\Collection\Collection([1, 2, 3, 4]);
echo $collection1->getFirstKeyFromValue(2);
```

Will output **1**

And :

```php
try {
    $collection1 = new \Small\Collection\Collection([1, 2, 3, 4]);
    echo $collection1->getFirstKeyFromValue(125);
} catch (\Small\Collection\Exception\CollectionException $e) {
    echo "not found";
}
```

Will output **not found**

#### getFirstKeyFromValueRecursive

This method is same as getFirstKeyFromValue but inspect sub arrays the result is an array where key **0** is first level and **x** is [x-1] level :

```php
$collection1 = new \Small\Collection\Collection([1, 2, [3.1, 3.2], 4]);
echo json_encode($collection1->getFirstKeyFromValue(3.2));
```

Will output :
```php
[2,1]
```

#### sort

This method sort the collection :

```php
$collection1 = new \Small\Collection\Collection([6, 2, 1, 4, ]);
$collection1->sort();
echo json_encode($collection1);
```

Will output :

```json
[1,2,4,6]
```

If the collection has sub collections/array, the sub collections will be sorted, except you specify false in first parameter :

```php
$collection1 = new \Small\Collection\Collection(['a' => 9, 'b' => 5, 'c' => [8,7]]);
$collection1->sort();
echo json_encode($collection1);
```

Will output :
```json
{"b":5,"a":9,"c":[7,8]}
```

And :

```php
$collection1 = new \Small\Collection\Collection(['a' => 9, 'b' => 5, 'c' => [8,7]]);
$collection1->sort(false);
echo json_encode($collection1);
```

Will output :
```json
{"b":5,"a":9,"c":[8,7]}
```

You can also specify a sort closure :

```php
$collection1 = new \Small\Collection\Collection([3, 2, 5]);
$collection1->sort(false, function($a, $b) {
if ($a==$b) return 0;
return ($a>$b)?-1:1;
});
```

Will output :
```json
[5,3,2]
```

#### ksort

This method is the same as *sort* method but sort on keys

#### intersect

This method intersect two collections in a new collection. This mean that new collection will have only values that are present in the two collections :

```php
use Small\Collection\Collection;
$collection1 = new Collection([1, 2, 3, 4, 5, 6, 7]);
$collection2 = new Collection([5, 6, 7, 8, 9, 10, 11, 12, 13]);
$collection3 = $collection1->intersect($collection2);
echo json_encode($collection3);
```

Will output :
```json
[5,6,7]
```

#### intersectKeys

This method return all keys of collection that are present on other collection. The values are the one of collection in parameters :

```php
use Small\Collection\Collection;
$collection1 = new Collection([1, 2, 3, 4, 5, 6, 7]);
$collection2 = new Collection([5, 6, 7, 8, 9, 10, 11, 12, 13]);
$collection3 = $collection1->intersect($collection2);
echo json_encode($collection3);
```

Will output :

```json
{"0": 5, "1": 6, "2":  7, "3": 8, "4": 9, "5": 10, "6":  11}
```

#### map

This method call a closure with key and value in parameter and gather result in a new collection :

```php
$collection1 = new \Small\Collection\Collection([1, 2]);
echo json_encode($collection1->map(function (mixed $key, mixed $value) {
    return [$key, $value];
}));
```

Will output :
```json
[[0, 1],[1, 2]]
```

#### values

This method create a new collection with values. The keys are reinitialized :

```php
$collection1 = new \Small\Collection\Collection(["a" => 1, "b" => 52]);
echo json_encode($collection1->values());
```

Will output :
```php
[1,52]
```

#### implode

This method create a new string with values separated by specified separator :

```php
$collection1 = new \Small\Collection\Collection(["a" => "P", "b" => "Z"]);
echo json_encode($collection1->implode(','));
```

Will output

```json
"P,Z"
```